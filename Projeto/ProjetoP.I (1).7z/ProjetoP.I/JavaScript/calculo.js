function calcularConsumo() {
    var registroMesAnterior = parseFloat(document.getElementById('mes_anterior').value);
    var registroMesAtual = parseFloat(document.getElementById('mes_atual').value);

    if (isNaN(registroMesAnterior) || isNaN(registroMesAtual)) {
        alert('Por favor, insira números válidos.');
        return;
    }

    var consumo = registroMesAtual - registroMesAnterior;

    if (consumo > 0 && consumo <= 5) {
        alert('Caro cliente, seu consumo este mês foi baixo');
    } else if (consumo > 5 && consumo <= 10) {
        alert('Caro cliente, seu consumo este mês foi moderado.');
    } else if (consumo => 20) {
        alert('Caro cliente, seu consumo este mês foi alto. Considere economizar água.');
        window.location.href = 'https://agergs.rs.gov.br/dica-do-dia-conheca-algumas-maneiras-de-economizar-agua-e-ajudar-o-meio-ambiente';
    } else {
        alert('Caro cliente, seu consumo este mês foi mínimo ou não houve consumo.');
    }
}